# asteroids_game
made by Stefan Herald, 0960543
--showing stuff on screen, saving and loading, pausing the game, storing and displaying scores
and by Jafar Al Ngaar, 4978579
--creating projectiles, collision, randomness